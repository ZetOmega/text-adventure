public class Main{
    public Main(){
        new GUI("GUI");

    }
public static void main(String[] args) {
    new Main();
  }
}

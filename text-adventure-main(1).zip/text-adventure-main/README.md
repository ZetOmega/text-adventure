# text-adventure
A text adventure made in school